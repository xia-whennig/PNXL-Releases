/*----------------------------------------------------------------------
 * Copyright (c) 2022 XIA LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, 
 * with or without modification, are permitted provided 
 * that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above 
 *     copyright notice, this list of conditions and the 
 *     following disclaimer.
 *   * Redistributions in binary form must reproduce the 
 *     above copyright notice, this list of conditions and the 
 *     following disclaimer in the documentation and/or other 
 *     materials provided with the distribution.
 *   * Neither the name of XIA LLC
 *     nor the names of its contributors may be used to endorse 
 *     or promote products derived from this software without 
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND 
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, 
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF 
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE 
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR 
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, 
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON 
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR 
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF 
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF 
 * SUCH DAMAGE.
 *----------------------------------------------------------------------*/

/******************************************************************************
 *
 * File name:
 *
 *      udp_xop64_c.c
 *
 * Description:
 *
 *      This file contains all the main driver funtions which
 *		can be used to control the Pixie modules.
 *
 * Member functions:
 *
 *	  int udp_receive__start
 *    int udp_receive__stop
 *    int udp_receive__poll
 *
 * Utilities from Pixie-4 library
 *    Pixie_Sleep
 *    Pixie_Print_MSG
 *
******************************************************************************/

#include <string.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

#include <io.h>
#include<winsock2.h>
#include<signal.h>
#pragma comment(lib,"ws2_32.lib") //Winsock Library

#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>

#include "globals.h"
#include "defs.h"
#include <XOPStandardHeaders.h>


#define BUFLEN 4096	//Max length of buffer
#define PORT 61002	//The port on which to listen for incoming data
#define XIA_WINDOZE

/****************************************************************
*	Pixie_Sleep function:
*		This routine serves as a wrapper for a system dependent
*              sleep-like function
*
*		Return Value:
*			 0 - good sleep 
*		      
*
****************************************************************/

int Pixie_Sleep (
				 double ms )			// Time in milliseconds
{

#ifdef XIA_WINDOZE
	Sleep((unsigned long)ms);
#endif
#ifdef XIA_LINUX
	usleep((unsigned long)(ms * 1000));
#endif

	return(0);
}



/****************************************************************
*	Pixie_Print_MSG function:
*		This routine prints error message or other message
*		either to Igor history window or a text file.
*
****************************************************************/

int Pixie_Print_MSG (
					 char *message, 	// message to be printed 
					 unsigned int enable )	// print it or not
{
	FILE *PIXIEmsg = NULL;
		
	if(!enable)	return(0);




	if(0) {
		// debug: optionally print the message to file
		

		PIXIEmsg = fopen("udp_xop64msg.txt", "a");
		if (PIXIEmsg != NULL)
		{
			/* Add new line character '\n' for printf */
			strcat(message, "\n");
			printf(message);

			fprintf(PIXIEmsg, "%s", message);
			fclose(PIXIEmsg);
		}

		//Pixie_Sleep(2);
	} else {
		// Add carriage return character '\r' for XOPNotice
		strcat(message, "\r");
		XOPNotice(message);
	}
/*

		// for LV dll etc

		PIXIEmsg = fopen("udp_xop64msg.txt", "a");
		if(PIXIEmsg != NULL)
		{
			// Add new line character '\n' for printf 
			strcat(message, "\n");
			printf(message);

			fprintf(PIXIEmsg, "%s", message);
			fclose(PIXIEmsg);
		}


*/
	return(0);
}

/****************************************************************
 *	udp_receive__start function:
 *		open socket etc to receive data, if something comes in, write to file
 *    adapted from https://www.binarytides.com/udp-socket-programming-in-winsock/

 *		Return Value:
 *			 0 if successful
 *			-1 invalid system type
 *			-2 Cannot initialize link to HV system
 *       -3 Cannot get crate map
 *
 ****************************************************************/

int udp_receive__start (     
			int  RTsource,       // runtype (dataformat) generated by Pixie-Net XL  - not yet implemented
			int  RTfile,         // runtype (dataformat) to be saved to file        - not yet implemented
			int  MaxPackages     // Take only a finite # of packages, 0 = infinite
			 )		 // 
{
 
   SOCKET s;
	struct sockaddr_in server, si_other;
	int slen , recv_len;
	char buf[BUFLEN];
	WSADATA wsa;
	FILE * fil;
   //int pck_count =0;
	int seg_count = 0;
	int debug_count = 0;
	int maxmsg = 20;
	int extra, Nextra, tracesegment;
	unsigned int runtype;
	unsigned int HDRLEN_410 = 62;	// Event header in bytes
	unsigned int zeros[BUFLEN] = { 0 };
    unsigned int dbg_msg = 0;  // turning on the xop notice give thread unsafe warning
    struct timeval tv;
    tv.tv_sec = 5;
    tv.tv_usec = 0;  // 100 ms timeout waiting for packets

   
   

	slen = sizeof(si_other) ;

   sprintf(ErrMSG, "*INFO* (udp_receive__start): inputs RTsource %d, RTfile %d, MaxPackages %d ", RTsource, RTfile, MaxPackages);
   Pixie_Print_MSG(ErrMSG,dbg_msg);

	
	//Initialise winsock	
   //printf("\nInitialising Winsock...");
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Initialising Winsock...");
   Pixie_Print_MSG(ErrMSG,dbg_msg);

	if (WSAStartup(MAKEWORD(2,2),&wsa) != 0)
	{
		//printf("Failed. Error Code : %d",WSAGetLastError());
      sprintf(ErrMSG, "*ERROR* (udp_receive__start): Failed. Error Code : %d",WSAGetLastError());
      Pixie_Print_MSG(ErrMSG,1);
		//exit(EXIT_FAILURE);
      MT_KeepPolling=0;
	   closesocket(s);
	   WSACleanup();
      return -1;
	}
	//printf("Initialised.\n");
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Initialised ok.");
   Pixie_Print_MSG(ErrMSG,dbg_msg);
	
	//Create a socket
	if((s = socket(AF_INET , SOCK_DGRAM , 0 )) == INVALID_SOCKET)
	{
		//printf("Could not create socket : %d" , WSAGetLastError());
      sprintf(ErrMSG, "*WARNING* (udp_receive__start): Could not create socket : %d" , WSAGetLastError());
      Pixie_Print_MSG(ErrMSG,1);
	}
	//printf("Socket created.\n");
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Socket created ok.");
   Pixie_Print_MSG(ErrMSG,dbg_msg);
	
	//Prepare the sockaddr_in structure
	server.sin_family = AF_INET;
	server.sin_addr.s_addr = INADDR_ANY;
	server.sin_port = htons( PORT );
	
	//Bind
	if( bind(s ,(struct sockaddr *)&server , sizeof(server)) == SOCKET_ERROR)
	{
		//printf("Bind failed with error code : %d" , WSAGetLastError());
		sprintf(ErrMSG, "*ERROR* (udp_receive__start): Bind failed with error code : %d" , WSAGetLastError());
      Pixie_Print_MSG(ErrMSG,1);
		//exit(EXIT_FAILURE);
      MT_KeepPolling=0;
	   closesocket(s);
	   WSACleanup();
      return -2;
	}
	//puts("Bind done");
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Bind done.");
   Pixie_Print_MSG(ErrMSG,dbg_msg);

   if (setsockopt(s, SOL_SOCKET, SO_RCVTIMEO,&tv,sizeof(tv)) < 0) {
      //perror("Error");
      sprintf(ErrMSG, "*ERROR* (udp_receive__start): socket timeout write unsucessful");
      Pixie_Print_MSG(ErrMSG,1);
		//exit(EXIT_FAILURE);
      MT_KeepPolling=0;
	   closesocket(s);
	   WSACleanup();
      return -3; 
   }

   fil = fopen("LMdata.bin","wb");

	//signal(SIGINT, sighandler);
	//printf("Waiting for data...press CTRL-C to quit\n");
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Waiting for data...");
   Pixie_Print_MSG(ErrMSG,dbg_msg);

	//keep listening for data
	//while(1)
   while( (pck_count<MaxPackages || MaxPackages==0) && MT_KeepPolling==1)
	{
		//printf("Waiting for data...");
		//fflush(stdout);
		
		//clear the buffer by filling null, it might have previously received data
		memset(buf,'\0;', BUFLEN);
		
		//try to receive some data, this is a blocking call
		// i.e. it waits in the if condition until data ready
		if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == SOCKET_ERROR)
		{
		   if( WSAGetLastError()!=10060) {	 // a timeout error is ok
            //printf("recvfrom() failed with error code : %d" , WSAGetLastError());
   			sprintf(ErrMSG, "*ERROR* (udp_receive__start): recvfrom() failed with error code : %d" , WSAGetLastError());
            Pixie_Print_MSG(ErrMSG,1);
   		   //exit(EXIT_FAILURE);
            MT_KeepPolling=0;
          	closesocket(s);
   	      WSACleanup();
            fclose(fil);
            return -4;
         }
		}
		
		//print details of the client/peer and the data received
		// one recvfrom is one UDP packet (is that always true??)
      if(pck_count % 10000 == 1) 
      {
      	//printf("Received packet %d from %s:%d\n", pck_count, inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
         sprintf(ErrMSG, "*INFO* (udp_receive__start): Received packet %d from %s:%d", pck_count, inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));
         Pixie_Print_MSG(ErrMSG,dbg_msg);
      }

      if(recv_len>0)
      {
        pck_count++;

		// --------- adjustments to data ------------
		runtype = buf[4] + (buf[5] << 8);
		tracesegment = (int)buf[57];


		//if (debug_count < maxmsg)	printf("packet # %d, Runtype 0x%x, traceseg %d  \n", pck_count, runtype, tracesegment);
		//debug_count++;

		if (runtype == 0x410)             // special treatment for mult-package events in 0x410
		{
			if (tracesegment == 0) // check word 28 for the traceseg counter  
			{
				//if (debug_count < maxmsg)	printf("packet # %d, Runtype 0x%x, traceseg 0  \n", pck_count, runtype);
				//debug_count++;

				// handle any lost segments before the start of a new event
				if (tracesegment != seg_count)   // ((seg_count > 0) & (seg_count < 7) )
				{
					Nextra = 8 - seg_count;
					//if (misseg_count < maxmsg)	printf("Lost part of multi-event packet (in packet # %d,  seg # is %d, seg # expected %d), inserting %d blocks of zeros  \n", pck_count, tracesegment, seg_count, Nextra);
					sprintf(ErrMSG, "*INFO* (udp_receive__start): Lost part of multi-event packet (in packet # %d,  seg # is %d, expected %d), inserting %d blocks of zeros", pck_count, tracesegment, seg_count, Nextra);
					Pixie_Print_MSG(ErrMSG, 1);
					misseg_count++;

					for (extra = 0; extra < Nextra; extra++)
					{
						fwrite(zeros, 1, recv_len - HDRLEN_410, fil);     // write zeros to file
					}
				}

				fwrite(buf, 1, recv_len, fil);     // write everything to file

				seg_count = 1;					// update expectation for next segment number 
			}
			else
			{
				//if (debug_count < maxmsg)	printf("packet # %d, Runtype 0x%x, traceseg > 0  \n", pck_count, runtype);
				//debug_count++;

				//seg_count++;

				if ((tracesegment < 8) & (tracesegment != seg_count))           // check for missing packets. 0 following 0 is ok (short trace), 8 is ok
				{

					if (tracesegment > seg_count) Nextra = tracesegment - seg_count;
					if (tracesegment < seg_count) Nextra = tracesegment - seg_count + 8;

					//if (misseg_count < maxmsg)	printf("Lost part of multi-event packet (in packet # %d,  seg # is %d, seg # expected %d), inserting %d blocks of zeros  \n", pck_count, tracesegment, seg_count, Nextra);
					sprintf(ErrMSG, "*INFO* (udp_receive__start): Lost part of multi-event packet (in packet # %d,  seg # is %d, expected %d), inserting %d blocks of zeros", pck_count, tracesegment, seg_count, Nextra);
					Pixie_Print_MSG(ErrMSG, 1);
					misseg_count++;
					
					for (extra = 0; extra < Nextra; extra++)
					{
						fwrite(zeros, 1, recv_len - HDRLEN_410, fil);     // write zeros to file
					}
				}

				fwrite(buf + HDRLEN_410, 1, recv_len - HDRLEN_410, fil);     // write trace only to file

				seg_count = tracesegment + 1;					  // reset expectation for next segment number 
				if (seg_count > 7) seg_count = 0;
			}

			//if (misseg_count % 20 == 1)
			//{
			//	printf("Lost parts of multi-event packets %d times \n", misseg_count);
			//	misseg_count++;		// count error 1 in N, but since it does not increment for successful packets, it would keep reporting N+1 lost
			//}

		}
		else  // other run types
		{
				fwrite(buf, 1, recv_len, fil);     // write to file
				//printf("Data: %s\n" , buf);
		}
      }
      else
      {
         sprintf(ErrMSG, "*INFO* (udp_receive__start): Repeating polling loop after timeout. MT_KeepPolling = %d", MT_KeepPolling);
		 Pixie_Print_MSG(ErrMSG, dbg_msg);
      }
      	
	}

   sprintf(ErrMSG, "*INFO* (udp_receive__start): Finished DAQ (%d packets, %d missed segments). MT_KeepPolling = %d", pck_count, misseg_count, MT_KeepPolling);
   Pixie_Print_MSG(ErrMSG,1);
   Pixie_Sleep(30);

   MT_KeepPolling=0;

   fclose(fil);
   //sprintf(ErrMSG, "*INFO* (udp_receive__start): closed file");
   //Pixie_Print_MSG(ErrMSG,1);
   Pixie_Sleep(30);

	closesocket(s);
   //sprintf(ErrMSG, "*INFO* (udp_receive__start): closed socket");
   //Pixie_Print_MSG(ErrMSG,1);
   Pixie_Sleep(30);

   WSACleanup();
   sprintf(ErrMSG, "*INFO* (udp_receive__start): Finished cleanup");
   Pixie_Print_MSG(ErrMSG,1);
   Pixie_Sleep(30);
	
	return 0;
}




/****************************************************************
 *	udp_receive__stop function:
 *   only used to print a message after MT_KeepPolling has been set to 0 in calling routine
 *		
 *
 ****************************************************************/

int udp_receive__stop (     
			double onoff,		 // init/deinit  
			double type )		 // system type        
{

   sprintf(ErrMSG, "*INFO* (udp_receive__stop ): Stopping polling thread (%d). Received %d packets, %d missing segments",MT_KeepPolling, pck_count, misseg_count);
   Pixie_Print_MSG(ErrMSG,1);

   return 0;

}

/****************************************************************
 *	udp_receive__poll function:
 *   print curerent status
 *
 ****************************************************************/

int udp_receive__poll (     
			double onoff,		 // init/deinit  
			double type )		 // system type  
{

   sprintf(ErrMSG, "*INFO* (udp_receive__poll ): Received %d packages, %d missing segments (MT_KeepPolling = %d).",pck_count, misseg_count, MT_KeepPolling);
   Pixie_Print_MSG(ErrMSG,1);

   return pck_count;

}
