﻿/*----------------------------------------------------------------------
 * Copyright (c) 2022 XIA LLC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms,
 * with or without modification, are permitted provided
 * that the following conditions are met:
 *
 *   * Redistributions of source code must retain the above
 *     copyright notice, this list of conditions and the
 *     following disclaimer.
 *   * Redistributions in binary form must reproduce the
 *     above copyright notice, this list of conditions and the
 *     following disclaimer in the documentation and/or other
 *     materials provided with the distribution.
 *   * Neither the name of XIA LLC
 *     nor the names of its contributors may be used to endorse
 *     or promote products derived from this software without
 *     specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
 * CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
 * INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
 * TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF
 * THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *----------------------------------------------------------------------*/


 /******************************************************************************
  *
  * File name:
  *
  *      udp_xop64.cpp
  *
  * Description:
  *
  *      UDP receiver functions seen by the Igor interface.
  *
  *
  * Member functions:
  *
  *	  udp_receive_start
  *	  udp_receive_stop
  *   udp_receive_poll
  *
  ******************************************************************************/

#include <windows.h>
#include <tchar.h>
#include <strsafe.h>
#include "XOPStandardHeaders.h"			// Include ANSI headers, Mac headers, IgorXOP.h, XOP.h and XOPSupport.h
#include <stdlib.h>
#include <stdio.h>
#include "defs.h"
#include "globals.h"
#include "udp_xop64.h"
#include "udp_xop64_c.h"



  // ******************** MT definitions   ********************

#define MAX_THREADS 1
#define BUF_SIZE 255


DWORD WINAPI MyThreadFunction(LPVOID lpParam);
void ErrorHandler(LPTSTR lpszFunction);

// Sample custom data structure for threads to use.
// This is passed by void pointer so it can be any data type
// that can be passed using a single void pointer (LPVOID).
typedef struct MyData {
	double result;
	double type;
	double  onoff;
} MYDATA, * PMYDATA;

PMYDATA pDataArray[MAX_THREADS];
DWORD   dwThreadIdArray[MAX_THREADS];
HANDLE  hThreadArray[MAX_THREADS];

// ******************** xop function definitions ********************

#pragma pack(2)		// All structures passed to Igor are two-byte aligned.
struct udp_receive_startParams {
    double p3;
	double p2;
	double p1;
	double result;
};
typedef struct udp_receive_startParams udp_receive_startParams;
#pragma pack()		// Reset structure alignment to default.

extern "C" int
udp_receive_start(udp_receive_startParams* p)
{
	//p->result = p->p1 + p->p2;

   	int i = 0;

   			//sprintf(ErrMSG, "*DEBUG* (udp_receive_start [MT ctrl]): thread starting RunStart");
			//	Pixie_Print_MSG(ErrMSG,1);
				
            // set globals
            RTsource       = (int)p->p3; //RunType_source;
            RTfile         = (int)p->p2; //RunType_file;
            MaxPackages    = (int)p->p1; //Max_Packages;
            MT_KeepPolling = 1;
            pck_count      = 0;
			misseg_count   = 0;

				/* Create MAX_THREADS worker threads */
				for(i=0; i<MAX_THREADS; i++)
				{
					// Allocate memory for thread data.
					pDataArray[i] = (PMYDATA) HeapAlloc(GetProcessHeap(), HEAP_ZERO_MEMORY, sizeof(MYDATA));
					if( pDataArray[i] == NULL )
					{
						// If the array allocation fails, the system is out of memory
						// so there is no point in trying to print an error message.
						// Just terminate execution.
						ExitProcess(2);
					}
					// Generate unique data for each thread to work with. 
					//pDataArray[i]->type = p->type;
					//pDataArray[i]->onoff = p->onoff;
					// Create the thread to begin execution on its own.
					hThreadArray[i] = CreateThread( 
							NULL,                   // default security attributes
							0,                      // use default stack size  
							MyThreadFunction,       // thread function name
							pDataArray[i],          // argument to thread function 
							0,                      // use default creation flags 
							&dwThreadIdArray[i]);   // returns the thread identifier 
					// Check the return value for success.
					// If CreateThread fails, terminate execution. 
					// This will automatically clean up threads and memory.
					if (hThreadArray[i] == NULL) 
					{
						ErrorHandler(TEXT("CreateThread"));
						ExitProcess(3);
					}
					// NB: assuming that there is only one thread (for polling), so dwThreadIdArray[0] is used to 
					// semafore the messages into msgBuffer!
					//pollingThreadId = dwThreadIdArray[0];
				} // End of main thread creation loop.
				//sprintf(ErrMSG, "*DEBUG* (udp_receive_start [MT ctrl]): thread done RunStart");
				//Pixie_Print_MSG(ErrMSG,1);

	//p->result=udp_receive__start(p->onoff, p->type);
	
	return(0);					/* XFunc error code */
}


#pragma pack(2)		// All structures passed to Igor are two-byte aligned.
struct udp_receive_stopParams {
	double p2;
	double p1;
	double result;
};
typedef struct udp_receive_stopParams udp_receive_stopParams;
#pragma pack()		// Reset structure alignment to default.

extern "C" int
udp_receive_stop(udp_receive_stopParams* p)
{
	//p->result = p->p1 / p->p2;
   MT_KeepPolling = 0;
	p->result=udp_receive__stop(p->p2, p->p1);
	//return (p->result);
	
	return(0);					/* XFunc error code */
}

#pragma pack(2)		// All structures passed to Igor are two-byte aligned.
struct udp_receive_pollParams  {
	double p2;
	double p1;
	double result;
};
typedef struct udp_receive_pollParams udp_receive_pollParams;
#pragma pack()		// Reset structure alignment to default.

extern "C" int
udp_receive_poll(udp_receive_pollParams* p)
{
	//p->result = 0; 
   p->result=udp_receive__poll(p->p2, p->p1);
	//return (p->result);	// a non-zero return value triggers an Igor error message

	return 0;
}

// ******************** xop interface functions ***********************

static XOPIORecResult
RegisterFunction()
{
	int funcIndex;

	funcIndex = (int)GetXOPItem(0);	/* which function invoked ? */
	switch (funcIndex) {
		case 0:						/* udp_receive_start(p1, p2, p3) */
			return (XOPIORecResult)udp_receive_start;
			break;
		case 1:						/* udp_receive_stop(p1, p2) */
			return (XOPIORecResult)udp_receive_stop;
			break;
		case 2:						/* udp_receive_poll(p1, p2) */
			return (XOPIORecResult)udp_receive_poll;
			break;
	}
	return 0;
}

/*	DoFunction()

	This will actually never be called because all of the functions use the direct method.
	It would be called if a function used the message method. See the XOP manual for
	a discussion of direct versus message XFUNCs.
*/
static int
DoFunction()
{
	int funcIndex;
	void *p;				/* pointer to structure containing function parameters and result */
	int err;

	funcIndex = (int)GetXOPItem(0);	/* which function invoked ? */
	p = (void*)GetXOPItem(1);		/* get pointer to params/result */
	switch (funcIndex) {
		case 0:						/* udp_xop64Add(p1, p2) */
			err = udp_receive_start((udp_receive_startParams*)p);
			break;
		case 1:						/* udp_xop64Div(p1, p2) */
			err = udp_receive_stop((udp_receive_stopParams*)p);
			break;
		case 2:						/* udp_xop64ComplexConjugate(p1) */
			err = udp_receive_poll((udp_receive_pollParams*)p);
			break;
	}
	return(err);
}

/*	XOPEntry()

	This is the entry point from the host application to the XOP for all messages after the
	INIT message.
*/

extern "C" void
XOPEntry(void)
{	
	XOPIORecResult result = 0;

	switch (GetXOPMessage()) {
		case FUNCTION:								/* our external function being invoked ? */
			result = DoFunction();
			break;

		case FUNCADDRS:
			result = RegisterFunction();
			break;
	}
	SetXOPResult(result);
}

/*	XOPMain(ioRecHandle)

	This is the initial entry point at which the host application calls XOP.
	The message sent by the host must be INIT.
	
	XOPMain does any necessary initialization and then sets the XOPEntry field of the
	ioRecHandle to the address to be called for future messages.
*/

HOST_IMPORT int
XOPMain(IORecHandle ioRecHandle)			// The use of XOPMain rather than main means this XOP requires Igor Pro 6.20 or later
{	
	XOPInit(ioRecHandle);					// Do standard XOP initialization
	SetXOPEntry(XOPEntry);					// Set entry point for future calls
	
	if (igorVersion < 620) {
		SetXOPResult(OLD_IGOR);
		return EXIT_FAILURE;
	}
	
	SetXOPResult(0);
	return EXIT_SUCCESS;
}





DWORD WINAPI MyThreadFunction( LPVOID lpParam ) 
{ 
    HANDLE hStdout;
    PMYDATA pDataArray;

    TCHAR msgBuf[BUF_SIZE];
    size_t cchStringSize;
    DWORD dwChars;

    // Make sure there is a console to receive output results. 

    hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
    if( hStdout == INVALID_HANDLE_VALUE )
        return 1;

    // Cast the parameter to the correct data type.
    // The pointer is known to be valid because 
    // it was checked for NULL before the thread was created.
 
    pDataArray = (PMYDATA)lpParam;
	
	/* Execute Pixie_Acquire_Data with the arguments 
	
	pDataArray->result=Pixie_Acquire_Data(pDataArray->Run_Type, 
										  pDataArray->UserData, 
										  pDataArray->filnam, 
										  pDataArray->ModNum);   */
   pDataArray->result=udp_receive__start(RTsource,RTfile,MaxPackages); //pDataArray->onoff, pDataArray->->type);

    // Print the parameter values using thread-safe functions.

    //StringCchPrintf(msgBuf, BUF_SIZE, TEXT("Parameters = %d, %d\n"), 
    //    pDataArray->Run_Type, pDataArray->ModNum); 
    //StringCchLength(msgBuf, BUF_SIZE, &cchStringSize);
    //WriteConsole(hStdout, msgBuf, (DWORD)cchStringSize, &dwChars, NULL);

    return 0; 
} 


void ErrorHandler(LPTSTR lpszFunction) 
{ 
    // Retrieve the system error message for the last-error code.

    LPVOID lpMsgBuf;
    LPVOID lpDisplayBuf;
    DWORD dw = GetLastError(); 

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | 
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        dw,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMsgBuf,
        0, NULL );

    // Display the error message.

    lpDisplayBuf = (LPVOID)LocalAlloc(LMEM_ZEROINIT, 
        (lstrlen((LPCTSTR) lpMsgBuf) + lstrlen((LPCTSTR) lpszFunction) + 40) * sizeof(TCHAR)); 
    StringCchPrintf((LPTSTR)lpDisplayBuf, 
        LocalSize(lpDisplayBuf) / sizeof(TCHAR),
        TEXT("%s failed with error %d: %s"), 
        lpszFunction, dw, lpMsgBuf); 
    MessageBox(NULL, (LPCTSTR) lpDisplayBuf, TEXT("Error"), MB_OK); 

    // Free error-handling buffer allocations.

    LocalFree(lpMsgBuf);
    LocalFree(lpDisplayBuf);
}
