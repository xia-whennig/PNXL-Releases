#ifndef XOP_STANDARD_REZ_HEADERS					// Skip if XOP standard resource headers have already been included

	#define XOP_STANDARD_REZ_HEADERS 1
	#define _IGORXOP_ 1
	#define MACIGOR
	
	#include "Carbon.r"
	#include "XOPTypes.r"

#endif				// XOP_STANDARD_REZ_HEADERS
