#!/bin/bash
./bootfpga > /var/www/autoboot.log
./progfippi >> /var/www/autoboot.log
