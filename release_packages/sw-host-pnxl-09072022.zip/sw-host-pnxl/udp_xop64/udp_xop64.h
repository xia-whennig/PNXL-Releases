﻿/*
	udp_xop64.h -- equates for udp_xop64 XOP
*/

/* udp_xop64 custom error codes */
#define OLD_IGOR 1 + FIRST_XOP_ERR

/* Prototypes */
HOST_IMPORT int XOPMain(IORecHandle ioRecHandle);
