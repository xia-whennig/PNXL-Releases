#define MAX_FILE_NAME_LENGTH	1024	// Maximum length of file names
#define MAX_PAR_NAME_LENGTH	65		// Maximum length of parameter names
#define DIR_READ     1
#define DIR_WRITE    0

#define BUFLEN 4096	//Max length of buffer
#define PORT 61002	//The port on which to listen for incoming data

#ifndef MAX
#define MAX(a,b)            (((a) > (b)) ? (a) : (b))
#endif

#ifndef MIN
#define MIN(a,b)            (((a) < (b)) ? (a) : (b))
#endif
